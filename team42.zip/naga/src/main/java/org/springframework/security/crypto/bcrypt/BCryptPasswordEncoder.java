package org.springframework.security.crypto.bcrypt;

public @interface BCryptPasswordEncoder {

	Object encode(Object password);

}
