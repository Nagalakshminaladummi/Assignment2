package com.example.security;

public class HttpSecurity {

}
