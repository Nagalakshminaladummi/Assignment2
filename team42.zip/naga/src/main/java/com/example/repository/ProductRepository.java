package com.example.repository;

import java.util.List;

import com.example.model.Product;

public class ProductRepository {

	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	public Product save(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteById(Long id) {
		// TODO Auto-generated method stub
		
	}

}
