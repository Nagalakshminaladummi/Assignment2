package com.example.service;

import com.example.model.User;

public class UserService {

	public User register(User user) {
		// TODO Auto-generated method stub
		return null;
	}

}
