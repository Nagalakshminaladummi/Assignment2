package com.example.model;

public class Product {

	public void setId(Long id) {
		// TODO Auto-generated method stub
		
	}

}
