package com.example.model;

public class User {

	public Object getPassword() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setPassword(Object encode) {
		// TODO Auto-generated method stub
		
	}

}
