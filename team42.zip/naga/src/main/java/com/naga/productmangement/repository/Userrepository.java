package com.naga.productmangement.repository;
com.naga.productmanagement.model;
import org.springframework.data.jpa.repository.JpaRepository;

import com.naga.productmanagement.model.User;

public interface Userrepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
}




