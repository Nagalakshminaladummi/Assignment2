package com.naga.productmanagement.conroller;

import java.util.List;

import com.example.model.Product;

public class ProductService {

	public List<Product> getAllProducts1() {
		// TODO Auto-generated method stub
		return null;
	}

	public Product addProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	public Product updateProduct(Long id, Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

}
