package com.naga.productmanagement.model;

public @interface Entity {

}
