
package com.naga.productmanagement.model;
import org.springframework.data.jpa.repository.JpaRepository;

import com.naga.productmanagement.model.Product;

public interface ProductRepository extends JpaRepository<Product, Long> {
}


	


	


